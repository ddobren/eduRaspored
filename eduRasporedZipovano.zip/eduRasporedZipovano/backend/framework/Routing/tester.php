<?php

class tester 
{
    public function __construct()
    {
        #Debug::dc(RouteRegistrar::$registeredRoutes);
        #(new RouteCompiler)->__construct();
    }
}
