<?php

declare(strict_types=1);

define("VN_ROOT_PATH", Paths::rootPath());

define("VN_PUBLIC_PATH", Paths::publicPath());

define("VN_APP_PATH", Paths::appPath());

define("VN_FRAMEWORK_PATH", Paths::frameworkPath());

define("VN_SELF_PATH", Paths::selfPath());
